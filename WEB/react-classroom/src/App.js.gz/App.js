import './App.css';
import Classroom from './Components/Classroom'

function App() {
  return (
    <div className="App">
      <Classroom nom="JS Dev"/>
    </div>
  )
}

export default App;
